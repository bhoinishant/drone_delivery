CREATE TABLE students(
student_name varchar(255) NOT NULL,
student_email varchar(255) NOT NULL,
student_contact int(255) NOT NULL,
student_address varchar(255) NOT NULL
);
