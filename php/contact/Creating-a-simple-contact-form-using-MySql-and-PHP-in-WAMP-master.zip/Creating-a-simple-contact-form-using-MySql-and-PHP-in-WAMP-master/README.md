# Creating-a-simple-contact-form-using-MySql-and-PHP-in-WAMP
Open the "EASY STEPS.odt" file and learn stepwise on how to create CONTACT FORM using WAMPSERVER. (The file is made in LibreOffice Writer)

If you can't access the above mentioned .odt file, visit to this link and learn how to create this project in WAMP: http://bit.ly/2umPCsm
